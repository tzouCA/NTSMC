clc
f=sim('Dynamics_Circular','Stoptime','60','MaxStep','0.009');%%  ,'Stoptime','60','MaxStep','0.009'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t1=f.get("t1");
t=t1(:,1);
figure(1)
tau=f.get("tau");
tauL=tau(:,1);
tauR=tau(:,2);
plot(t,tauL,'r','LineWidth',1.5)
hold on
plot(t,tauR,'b','LineWidth',1.5)
axis([0 inf -135 130])
grid
xlabel('$\textbf{t}$ $\textbf{(sec)}$','FontSize',12,'FontWeight','bold','interpreter','latex')
ylabel('$\boldmath{\tau}$ $\textbf{(Nm)}$','FontSize',12,'FontWeight','bold','interpreter','latex')
%title('$\textbf{Torque}$','FontSize',12,'FontWeight','bold','interpreter','latex')
h = legend('$\textbf{Left Side Torque}$','$\textbf{Right Side Torque}$','Location','northeast');
h.Interpreter = "latex";
h.FontSize = 12;
h.NumColumns= 2

figure(2)
Actual_pos=f.get('Actual_pos');
x=Actual_pos(:,1);
y=Actual_pos(:,2);
plot(x,y,'b-<',"MarkerIndices",[1500 4000 6200],'LineWidth',1.5)
hold on
ref=f.get('ref');
xref=ref(:,1);
yref=ref(:,2);
plot(xref,yref,'r--','LineWidth',1.5)
hold on
plot(x(1,1),y(2,1),'ko')
%axis([-16 5.5 -2.0 21])
axis([-4 2.5 -1 6])  
grid
xlabel('$\textbf{X}$ $\textbf{(m)}$','FontSize',12,'FontWeight','bold','interpreter','latex')
ylabel('$\textbf{Y}$ $\textbf{(m)}$','FontSize',12,'FontWeight','bold','interpreter','latex')
%title('$\textbf{Trajectory Tracking}$','FontSize',12,'FontWeight','bold','interpreter','latex')
h = legend('$\textbf{Simulated Path}$','$\textbf{Desired Path}$','Location','northeast');
h.Interpreter = "latex";
h.FontSize = 12;
h.NumColumns= 2
zDot_c=f.get('zDot_c');
zDot_c1=zDot_c(1,:);
zDot_c2=zDot_c(2,:);
zDot=f.get('zDot');
zDot_1=zDot(:,1);
zDot_2=zDot(:,2);
figure(3)
plot(t,zDot_c1,'r--','LineWidth',1.5)
hold on
plot(t,zDot_1,'b','LineWidth',1.5)
%axis([0 inf -0.2 0.7])    modified
axis([0 inf -0.8 2.7])  
grid
xlabel('$\textbf{t}$ $\textbf{(sec)}$','FontSize',12,'FontWeight','bold','interpreter','latex')
ylabel('$\textbf{Linear Velocity}$ $\textbf{(m/sec)}$','FontSize',12,'FontWeight','bold','interpreter','latex')
%title('$\textbf{Linear Velocity}$','FontSize',12,'FontWeight','bold','interpreter','latex')
h = legend('$\boldmath{\upsilon_{c}}$','$\boldmath{\upsilon}$','Location','northeast'); 
h.Interpreter = "latex";
h.FontSize = 12;
h.NumColumns= 2
figure(4)
plot(t,zDot_c2,'r--','LineWidth',1.5)
hold on
plot(t,zDot_2,'b','LineWidth',1.5)
axis([0 inf -0.5 0.8])
grid
xlabel('$\textbf{t}$ $\textbf{(sec)}$','FontSize',12,'FontWeight','bold','interpreter','latex')
ylabel('$\textbf{Angular Velocity}$ $\textbf{(rad/sec)}$','FontSize',12,'FontWeight','bold','interpreter','latex')
%title('$\textbf{Angular Velocity}$','FontSize',12,'FontWeight','bold','interpreter','latex')
h = legend('$\boldmath{\omega_{c}}$','$\boldmath{\omega}$','Location','northeast'); 
h.Interpreter = "latex";
h.FontSize = 12;
h.NumColumns= 2

%%% position
q=f.get('q');
q1=q(1,:);
q2=q(2,:);
q3=q(3,:);
q_ref=f.get('q_ref');
q_ref1=q_ref(1,:);
q_ref2=q_ref(2,:);
q_ref3=q_ref(3,:);
figure(5)
s1=f.get('s1');
s2=f.get('s2');
plot(t,s1,'r--','LineWidth',1.5)
hold on
plot(t,s2,'b','LineWidth',1.5)
grid
xlabel('$\textbf{t}$ $\textbf{(sec)}$','FontSize',7,'FontWeight','bold','interpreter','latex')
ylabel('$\textbf{Sliding Surface}$','FontSize',7,'FontWeight','bold','interpreter','latex')
%title('$\textbf{Sliding Surface}$','FontSize',12,'FontWeight','bold','interpreter','latex')
h = legend('$\boldmath{S_{1}}$','$\boldmath{S_{2}}$','Location','northeast'); 
h.Interpreter = "latex";
h.FontSize = 7;
h.NumColumns= 2

figure(6)
yyaxis left
plot(t,q1,'r','LineWidth',1.5)
hold on
yyaxis left
plot(t,q_ref1,'--k','LineWidth',1.5)
hold on
yyaxis left
plot(t,q2,'b','LineWidth',1.5)
hold on
yyaxis left
plot(t,q_ref2,'--k','LineWidth',1.5)
xlabel('$\textbf{t}$ $\textbf{(sec)}$','FontSize',12,'FontWeight','bold','interpreter','latex')
ylabel('$\textbf{x,y}$ $\textbf{(m)}$','FontSize',12,'FontWeight','bold','interpreter','latex')
hold on
yyaxis right
plot(t,q3,'m','LineWidth',1.5)
hold on
yyaxis right
plot(t,q_ref3,'--k','LineWidth',1.5)
grid
xlabel('$\textbf{t}$ $\textbf{(sec)}$','FontSize',12,'FontWeight','bold','interpreter','latex')
ylabel('$\boldmath{\theta}$ $\textbf{(rad)}$','FontSize',12,'FontWeight','bold','interpreter','latex')
%title('$\textbf{Sliding Surface}$','FontSize',12,'FontWeight','bold','interpreter','latex')
h = legend('$\boldmath{x}$','$\boldmath{x_{ref}}$','$\boldmath{y}$','$\boldmath{y_{ref}}$','$\boldmath{\theta}$','$\boldmath{\theta_{ref}}$','Location','northeast'); 
h.Interpreter = "latex";
h.FontSize = 12;
h.NumColumns= 2

